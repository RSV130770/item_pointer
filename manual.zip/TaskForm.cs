using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace LedMatrixControl
{
    public class TaskForm : Form
    {
        private readonly LedMatrixConfig _config;
        private readonly AppUser _user;
        private readonly LabelStore _labels;
        private readonly OperationsLog _log;

        private IRelayCommutator _relay;
        private LedMatrix _matrix;
        private ScaleReader _scale;
        private readonly System.Windows.Forms.Timer _healthCheckTimer = new() { Interval = 8000 };
        private bool _lastHardwareOk = true;
        private bool _relayOk;
        private bool _scaleOk;

        public event Action LogoutRequested;

        // -- UI, sized for a big touchscreen --
        private readonly Label _userLabel = new() { Font = new Font(FontFamily.GenericSansSerif, 14, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
        private readonly Button _logoutButton = new() { Text = "Log out", Font = new Font(FontFamily.GenericSansSerif, 14) };
        private readonly Button _loadButton = new() { Text = "Load latest task", Font = new Font(FontFamily.GenericSansSerif, 14) };
        private readonly Label _taskNameLabel = new() { Text = "(no task loaded)", Font = new Font(FontFamily.GenericSansSerif, 14, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
        private readonly Button _skipButton = new() { Text = "Skip item", Font = new Font(FontFamily.GenericSansSerif, 14), BackColor = Color.MistyRose };
        private readonly Button _addButton = new() { Text = "Add item", Font = new Font(FontFamily.GenericSansSerif, 12) };
        private readonly Button _editButton = new() { Text = "Edit item", Font = new Font(FontFamily.GenericSansSerif, 12) };
        private readonly Button _deleteButton = new() { Text = "Delete item", Font = new Font(FontFamily.GenericSansSerif, 12), BackColor = Color.MistyRose };

        private readonly Label _hardwareStatusLabel = new() { Text = "Checking hardware...", Font = new Font(FontFamily.GenericSansSerif, 12, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
        private readonly Button _recheckButton = new() { Text = "Recheck hardware", Font = new Font(FontFamily.GenericSansSerif, 12) };
        private readonly Button _openMatrixButton = new() { Text = "LED matrix (tech)", Font = new Font(FontFamily.GenericSansSerif, 12) };

        private readonly Label _currentItemLabel = new() { Text = "--", Font = new Font(FontFamily.GenericSansSerif, 22, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter };
        private readonly Label _currentWeightLabel = new() { Text = "-- g", Font = new Font(FontFamily.GenericSansSerif, 40, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter };
        private readonly Label _expectedWeightLabel = new() { Text = "expected: --", Font = new Font(FontFamily.GenericSansSerif, 16), TextAlign = ContentAlignment.MiddleCenter };
        private readonly Label _statusLabel = new() { Text = "", Font = new Font(FontFamily.GenericSansSerif, 18, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter };

        private readonly ListView _listView = new() { View = View.Details, FullRowSelect = true, Dock = DockStyle.Fill, GridLines = true, Font = new Font(FontFamily.GenericSansSerif, 11) };
        private readonly TextBox _logBox = new() { Multiline = true, ScrollBars = ScrollBars.Vertical, ReadOnly = true, Dock = DockStyle.Fill, Font = new Font(FontFamily.GenericSansSerif, 9) };

        private List<TaskItem> _items = new();
        private int _currentIndex = -1;
        private string _currentTaskFilePath;

        public TaskForm(LedMatrixConfig config, AppUser user)
        {
            _config = config;
            _user = user;
            _labels = new LabelStore(ResolveNextToConfig("index.json"));
            _log = new OperationsLog(AppDomain.CurrentDomain.BaseDirectory, config.LogFolderPath);

            Text = "Picking task";
            WindowState = FormWindowState.Maximized;
            FormBorderStyle = FormBorderStyle.None;

            BuildLayout();
            WireEvents();

            _log.Log(_user.Id, _user.Name, "Login", "");
            ConnectHardwareSilently();
        }

        private static string ResolveNextToConfig(string fileName)
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);
        }

        private void BuildLayout()
        {
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5 };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));   // top bar
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));   // hardware status bar
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 250));  // current item panel
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));  // list
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 90));  // log (small, technician-visible)

            var topBar = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1 };
            topBar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40));
            topBar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            topBar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160));
            topBar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            _userLabel.Dock = DockStyle.Fill;
            _taskNameLabel.Dock = DockStyle.Fill;
            _loadButton.Dock = DockStyle.Fill;
            _logoutButton.Dock = DockStyle.Fill;
            _loadButton.Margin = new Padding(5);
            _logoutButton.Margin = new Padding(5);
            topBar.Controls.Add(_userLabel, 0, 0);
            topBar.Controls.Add(_taskNameLabel, 1, 0);
            topBar.Controls.Add(_loadButton, 2, 0);
            topBar.Controls.Add(_logoutButton, 3, 0);
            root.Controls.Add(topBar, 0, 0);

            var statusBar = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1 };
            statusBar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60));
            statusBar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160));
            statusBar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160));
            _hardwareStatusLabel.Dock = DockStyle.Fill;
            _hardwareStatusLabel.Padding = new Padding(10, 0, 0, 0);
            _recheckButton.Dock = DockStyle.Fill;
            _recheckButton.Margin = new Padding(5);
            _openMatrixButton.Dock = DockStyle.Fill;
            _openMatrixButton.Margin = new Padding(5);
            statusBar.Controls.Add(_hardwareStatusLabel, 0, 0);
            statusBar.Controls.Add(_recheckButton, 1, 0);
            statusBar.Controls.Add(_openMatrixButton, 2, 0);
            root.Controls.Add(statusBar, 0, 1);

            var currentPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            currentPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65));
            currentPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35));

            var infoStack = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
            infoStack.RowStyles.Add(new RowStyle(SizeType.Percent, 45));
            infoStack.RowStyles.Add(new RowStyle(SizeType.Percent, 30));
            infoStack.RowStyles.Add(new RowStyle(SizeType.Percent, 25));
            _currentItemLabel.Dock = DockStyle.Fill;
            _expectedWeightLabel.Dock = DockStyle.Fill;
            _statusLabel.Dock = DockStyle.Fill;
            infoStack.Controls.Add(_currentItemLabel, 0, 0);
            infoStack.Controls.Add(_expectedWeightLabel, 0, 1);
            infoStack.Controls.Add(_statusLabel, 0, 2);
            currentPanel.Controls.Add(infoStack, 0, 0);

            var weightAndSkip = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
            weightAndSkip.RowStyles.Add(new RowStyle(SizeType.Percent, 40));
            weightAndSkip.RowStyles.Add(new RowStyle(SizeType.Percent, 40));
            weightAndSkip.RowStyles.Add(new RowStyle(SizeType.Percent, 20));
            _currentWeightLabel.Dock = DockStyle.Fill;
            _skipButton.Dock = DockStyle.Fill;
            _skipButton.Margin = new Padding(15);
            weightAndSkip.Controls.Add(_currentWeightLabel, 0, 0);
            weightAndSkip.Controls.Add(_skipButton, 0, 1);

            var editRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1 };
            editRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3f));
            editRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3f));
            editRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3f));
            _addButton.Dock = DockStyle.Fill;
            _editButton.Dock = DockStyle.Fill;
            _deleteButton.Dock = DockStyle.Fill;
            _addButton.Margin = new Padding(5);
            _editButton.Margin = new Padding(5);
            _deleteButton.Margin = new Padding(5);
            editRow.Controls.Add(_addButton, 0, 0);
            editRow.Controls.Add(_editButton, 1, 0);
            editRow.Controls.Add(_deleteButton, 2, 0);
            weightAndSkip.Controls.Add(editRow, 0, 2);

            currentPanel.Controls.Add(weightAndSkip, 1, 0);

            root.Controls.Add(currentPanel, 0, 2);

            _listView.Columns.Add("#", 40);
            _listView.Columns.Add("Label", 70);
            _listView.Columns.Add("Name", 260);
            _listView.Columns.Add("Unit weight", 100);
            _listView.Columns.Add("Qty", 70);
            _listView.Columns.Add("Expected total", 120);
            _listView.Columns.Add("Length (mm)", 100);
            root.Controls.Add(_listView, 0, 3);

            root.Controls.Add(_logBox, 0, 4);

            Controls.Add(root);
        }

        private void WireEvents()
        {
            _userLabel.Text = $"Operator: {_user.Name}";
            _logoutButton.Click += (s, e) => DoLogout();
            _loadButton.Click += async (s, e) => await LoadLatestFile();
            _skipButton.Click += async (s, e) => await SkipCurrent();
            _recheckButton.Click += async (s, e) => await RecheckHardware();
            _healthCheckTimer.Tick += (s, e) =>
            {
                if (_healthCheckRunning)
                    return; // previous check still in flight (e.g. a slow full reconnect) - skip this tick
                _healthCheckRunning = true;
                Task.Run(() =>
                {
                    try { HealthCheckTick(); }
                    finally { _healthCheckRunning = false; }
                });
            };
            _openMatrixButton.Click += (s, e) => OpenMatrixView();
            _addButton.Click += async (s, e) => await AddItem();
            _editButton.Click += async (s, e) => await EditCurrentItem();
            _deleteButton.Click += async (s, e) => await DeleteCurrentItem();
        }

        private void OpenMatrixView()
        {
            if (_matrix == null)
            {
                MessageBox.Show(this, "Relay hardware is not connected right now - fix that first (see status bar / Recheck hardware).",
                    "No relay connection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            new RelayControlForm(_config, _matrix).Show();
        }

        private void ConnectHardwareSilently() => ConnectHardware(verbose: true);

        private void ConnectHardware(bool verbose)
        {
            DisposeHardware();

            var report = StartupDiagnostics.RunAll(_config, verbose ? Log : (Action<string>)null);
            if (report.ConfigWasModified)
            {
                try { _config.SaveToFile("config.json"); }
                catch (Exception ex) { Log($"Could not persist auto-corrected config: {ex.Message}"); }
            }

            var relayOk = report.Results.FirstOrDefault(r => r.Name == "Relay port")?.Ok ?? false;
            var scaleOk = report.Results.FirstOrDefault(r => r.Name == "Scale port")?.Ok ?? false;

            if (relayOk)
            {
                try
                {
                    _relay = new ModbusRelayCommutator(_config.SerialPort);
                    _matrix = new LedMatrix(_relay, _config);
                    _matrix.ResetToKnownState(); // verified all-off baseline; physical relays could be in any state left over from before
                }
                catch (Exception ex)
                {
                    relayOk = false;
                    if (verbose) Log($"Relay connect failed: {ex.Message}");
                }
            }

            if (scaleOk)
            {
                try
                {
                    _scale = new ScaleReader(_config.ScalePort);
                    _scale.StableWeightReceived += grams =>
                    {
                        if (IsHandleCreated) BeginInvoke((Action)(() => OnWeightReceived(grams)));
                    };
                    _scale.Disconnected += message =>
                    {
                        if (IsHandleCreated) BeginInvoke((Action)(() => OnScaleDisconnected(message)));
                    };
                    _scale.Start();
                }
                catch (Exception ex)
                {
                    scaleOk = false;
                    if (verbose) Log($"Scale connect failed: {ex.Message}");
                }
            }

            _relayOk = relayOk;
            _scaleOk = scaleOk;

            var nowOk = relayOk && scaleOk;
            if (!verbose && nowOk != _lastHardwareOk)
            {
                Log(nowOk
                    ? "Hardware recovered - relay and scale both OK."
                    : $"Still down - Relay: {(relayOk ? "OK" : "PROBLEM")}, Scale: {(scaleOk ? "OK" : "PROBLEM")}");
            }
            _lastHardwareOk = nowOk;

            UpdateHardwareStatus(relayOk, scaleOk);

            // Kept running continuously rather than only while something's
            // broken: the relay is request/response only (unlike the scale,
            // which pushes data and reports its own disconnects) - the only
            // way to know it's still there is to keep actively probing it.
            StartAutoRecheck();
        }

        /// <summary>
        /// Runs every 8s. Unlike the scale (which pushes data and reports
        /// its own disconnects), the relay only ever responds when we write
        /// to it - so it needs active probing to know it's still there. If
        /// both devices already have a working connection, this does a
        /// cheap probe over the relay's *existing* connection only (no port
        /// reopen, and the scale isn't touched at all - it's trusted to
        /// report its own problems). A full reconnect (with port
        /// re-detection) only happens when something is actually missing.
        /// </summary>
        private int _relayConsecutiveFailures;
        private volatile bool _healthCheckRunning;

        private void HealthCheckTick()
        {
            if (_relay == null || _scale == null)
            {
                // Something isn't connected at all yet - do a full
                // (re)detection pass, same as startup/manual recheck.
                ConnectHardware(verbose: false);
                return;
            }

            try
            {
                _relay.SelectChannel(_config.RowCommutator.Address, 1, turnOn: false); // harmless idempotent probe, reuses the existing connection
                _relayConsecutiveFailures = 0;
                if (!_relayOk)
                {
                    _relayOk = true;
                    Log("Relay recovered (probe succeeded).");
                }
            }
            catch (Exception ex)
            {
                if (_relayOk)
                    OnRelayError(ex.Message);

                _relayConsecutiveFailures++;
                if (_relayConsecutiveFailures >= 3)
                {
                    // The existing connection is dead, not just a blip -
                    // drop it entirely so the next tick does a full
                    // re-detection pass (needed in case the device came
                    // back on a different COM port, e.g. a replugged
                    // USB-serial adapter).
                    Log("Relay still unresponsive after 3 probes - dropping connection for full re-detection.");
                    (_relay as IDisposable)?.Dispose();
                    _relay = null;
                    _matrix = null;
                    _relayConsecutiveFailures = 0;
                    return;
                }
            }

            _lastHardwareOk = _relayOk && _scaleOk;
            UpdateHardwareStatus(_relayOk, _scaleOk);
        }

        private void StartAutoRecheck()
        {
            if (IsHandleCreated && InvokeRequired)
            {
                BeginInvoke((Action)StartAutoRecheck);
                return;
            }
            if (_healthCheckTimer.Enabled)
                return;
            _healthCheckTimer.Enabled = true;
            Log("Continuous hardware health check started (every 8s) - the relay can only be checked by actively probing it, unlike the scale.");
        }

        private void StopAutoRecheck()
        {
            if (IsHandleCreated && InvokeRequired)
            {
                BeginInvoke((Action)StopAutoRecheck);
                return;
            }
            _healthCheckTimer.Enabled = false;
        }

        private async Task RecheckHardware()
        {
            _recheckButton.Enabled = false;
            _hardwareStatusLabel.Text = "Rechecking...";
            _hardwareStatusLabel.ForeColor = Color.DimGray;

            try
            {
                // Log() and UpdateHardwareStatus() are both thread-safe now
                // (they marshal to the UI thread themselves), so the actual
                // probing can run in the background without freezing the
                // window - the operator can keep using the rest of the
                // screen while this runs.
                await Task.Run(() => ConnectHardwareSilently());
            }
            finally
            {
                _recheckButton.Enabled = true;
            }
        }

        private void OnScaleDisconnected(string message)
        {
            Log(message);
            _lastHardwareOk = false;
            _scaleOk = false;
            UpdateHardwareStatus(_relayOk, _scaleOk);
            StartAutoRecheck();
        }

        /// <summary>
        /// Called whenever a relay write fails during active use (not just
        /// at connect time) - e.g. the cable gets unplugged mid-task. Never
        /// lets that exception surface to the operator as a crash/error
        /// dialog: just flags the status banner and lets the auto-recheck
        /// loop quietly reconnect once the hardware is back.
        /// </summary>
        private void OnRelayError(string message)
        {
            Log($"Relay error: {message}");
            _lastHardwareOk = false;
            _relayOk = false;
            UpdateHardwareStatus(_relayOk, _scaleOk);
            StartAutoRecheck();
        }

        private void UpdateHardwareStatus(bool relayOk, bool scaleOk)
        {
            if (_hardwareStatusLabel.IsHandleCreated && _hardwareStatusLabel.InvokeRequired)
            {
                BeginInvoke((Action)(() => UpdateHardwareStatus(relayOk, scaleOk)));
                return;
            }

            if (relayOk && scaleOk)
            {
                _hardwareStatusLabel.Text = "Relay: OK   Scale: OK";
                _hardwareStatusLabel.ForeColor = Color.Green;
            }
            else
            {
                _hardwareStatusLabel.Text = $"Relay: {(relayOk ? "OK" : "PROBLEM")}   Scale: {(scaleOk ? "OK" : "PROBLEM")} - press Recheck hardware";
                _hardwareStatusLabel.ForeColor = Color.Red;
            }
        }

        private async Task<bool> SetLedByLabel(string label)
        {
            if (_matrix == null)
                return false;

            if (!_labels.TryFind(label, out int row, out int col))
                return false;

            try
            {
                await Task.Run(() => _matrix.SetLed(row, col));
                return true;
            }
            catch (Exception ex)
            {
                OnRelayError(ex.Message);
                return false;
            }
        }

        private async Task LoadLatestFile()
        {
            _loadButton.Enabled = false;
            string folderStatusMessage = null;
            try
            {
                var (folder, items, fileName) = await Task.Run(() =>
                {
                    var (resolvedFolder, statusMessage) = ResolveTaskFolder();
                    if (statusMessage != null)
                        folderStatusMessage = statusMessage;

                    var newestFile = new DirectoryInfo(resolvedFolder)
                        .GetFiles("*.csv")
                        .OrderByDescending(f => f.LastWriteTimeUtc)
                        .FirstOrDefault();

                    if (newestFile == null)
                        return (resolvedFolder, (List<TaskItem>)null, (string)null);

                    Log($"Attempting to load: {newestFile.FullName} (last modified {newestFile.LastWriteTime:yyyy-MM-dd HH:mm:ss})");

                    var loaded = TaskCsvLoader.Load(newestFile.FullName);
                    return (resolvedFolder, loaded, newestFile.FullName);
                });

                if (folderStatusMessage != null)
                    Log(folderStatusMessage);

                if (items == null)
                {
                    Log($"No CSV files found in {folder}");
                    return;
                }

                _items = items;
                _taskNameLabel.Text = Path.GetFileNameWithoutExtension(fileName);
                _currentTaskFilePath = fileName;
                Log($"Loaded {_items.Count} rows from {fileName}");
                _log.Log(_user.Id, _user.Name, "TaskLoaded", Path.GetFileName(fileName));

                PopulateListView();
                _currentIndex = -1;
                await AdvanceTo(0);
            }
            catch (Exception ex)
            {
                Log($"Failed to load task file: {ex.Message}");
            }
            finally
            {
                _loadButton.Enabled = true;
            }
        }

        private (string Folder, string Message) ResolveTaskFolder()
        {
            var localFolder = AppDomain.CurrentDomain.BaseDirectory;
            try
            {
                if (Directory.Exists(_config.TaskFolderPath))
                    return (_config.TaskFolderPath, null);
                return (localFolder, $"Network task folder not reachable: {_config.TaskFolderPath}. Falling back to {localFolder}");
            }
            catch (Exception ex)
            {
                return (localFolder, $"Network task folder check failed: {ex.Message}. Falling back to {localFolder}");
            }
        }

        private void PopulateListView()
        {
            _listView.Items.Clear();
            for (int i = 0; i < _items.Count; i++)
            {
                var item = _items[i];
                var row = new ListViewItem(new[]
                {
                    (i + 1).ToString(),
                    item.Index,
                    item.Name,
                    item.Weight.ToString("0.###"),
                    item.Quantity.ToString(),
                    item.ExpectedTotalWeight.ToString("0.###"),
                    item.LengthMm?.ToString("0.###") ?? ""
                });
                _listView.Items.Add(row);
            }
        }

        private async Task AdvanceTo(int index)
        {
            if (_currentIndex >= 0 && _currentIndex < _listView.Items.Count)
                _listView.Items[_currentIndex].BackColor = SystemColors.Window;

            _currentIndex = index;

            if (_currentIndex >= _items.Count)
            {
                _currentItemLabel.Text = "Task complete";
                _expectedWeightLabel.Text = "";
                _statusLabel.Text = "";
                _skipButton.Enabled = false;
                Log("Task complete.");
                _log.Log(_user.Id, _user.Name, "TaskComplete", _taskNameLabel.Text);

                await OfferRepeatOrDone();
                return;
            }

            _skipButton.Enabled = true;
            var item = _items[_currentIndex];
            _listView.Items[_currentIndex].BackColor = Color.LimeGreen;
            _listView.Items[_currentIndex].EnsureVisible();
            _currentItemLabel.Text = $"{item.Name}  [{item.Index}]";
            _expectedWeightLabel.Text = $"expected: {item.ExpectedTotalWeight:0.###} g  (x{item.Quantity})";
            _statusLabel.Text = "";

            if (string.IsNullOrWhiteSpace(item.Index))
            {
                // No LED label for this row: just clear every LED and rely
                // on the scale check alone - there's nothing to look up.
                if (_matrix != null)
                {
                    try { await Task.Run(() => _matrix.AllOff()); }
                    catch (Exception ex) { OnRelayError(ex.Message); }
                }
            }
            else
            {
                var found = await SetLedByLabel(item.Index);
                if (!found)
                    Log($"WARNING: no LED found for label \"{item.Index}\"");
            }
        }

        /// <summary>
        /// Shown once the whole task list has been completed. Repeat starts
        /// the same loaded list over from the top; Done just leaves things
        /// as finished (the operator can Load a new task whenever ready).
        /// </summary>
        private async Task OfferRepeatOrDone()
        {
            if (_items.Count == 0)
                return; // nothing was ever loaded - don't prompt on startup

            using var dialog = new TaskCompleteDialog(_taskNameLabel.Text, _items.Count);
            var result = dialog.ShowDialog(this);

            _log.Log(_user.Id, _user.Name, "TaskCompleteChoice", result == DialogResult.Retry ? "Repeat" : "Done");

            if (result == DialogResult.Retry)
            {
                _currentIndex = -1;
                await AdvanceTo(0);
            }
        }

        private double CurrentPrecision()
        {
            var item = _currentIndex >= 0 && _currentIndex < _items.Count ? _items[_currentIndex] : null;
            return item?.Precision ?? _config.DefaultPrecisionGrams;
        }

        private async void OnWeightReceived(double grams)
        {
            try
            {
                _currentWeightLabel.Text = $"{grams:0.0} g";

                if (Math.Abs(grams) < _config.MinimumValidWeightGrams)
                {
                    _statusLabel.Text = "(scale near zero)";
                    _statusLabel.ForeColor = Color.Gray;
                    return;
                }

                if (_currentIndex < 0 || _currentIndex >= _items.Count)
                    return;

                var item = _items[_currentIndex];
                var expected = item.ExpectedTotalWeight;
                var precision = CurrentPrecision();
                var diff = grams - expected;

                if (Math.Abs(diff) <= precision)
                {
                    _statusLabel.Text = "OK";
                    _statusLabel.ForeColor = Color.Green;
                    Log($"Row {_currentIndex + 1} OK: {grams:0.0}g (expected {expected:0.###}g +/-{precision:0.###}g)");
                    _log.Log(_user.Id, _user.Name, "RowCompleted", $"{item.Index} | {item.Name} | actual={grams:0.0}g expected={expected:0.###}g");
                    await AdvanceTo(_currentIndex + 1);
                }
                else
                {
                    _statusLabel.Text = $"diff: {diff:+0.0;-0.0} g";
                    _statusLabel.ForeColor = Color.OrangeRed;
                }
            }
            catch (Exception ex)
            {
                // async void - nothing else can catch this. Never let a
                // weight-processing hiccup take the whole app down.
                Log($"Unexpected error handling weight reading: {ex.Message}");
            }
        }

        private async Task SkipCurrent()
        {
            if (_currentIndex < 0 || _currentIndex >= _items.Count)
                return;

            var item = _items[_currentIndex];
            using var reasonForm = new SkipReasonForm(item.Name);
            if (reasonForm.ShowDialog(this) != DialogResult.OK)
                return;

            Log($"Row {_currentIndex + 1} SKIPPED: {item.Index} | {item.Name} | reason: {reasonForm.SelectedReason}");
            _log.Log(_user.Id, _user.Name, "RowSkipped", $"{item.Index} | {item.Name} | reason={reasonForm.SelectedReason}");
            await AdvanceTo(_currentIndex + 1);
        }

        private async Task AddItem()
        {
            using var editForm = new TaskItemEditForm(null, isNewItem: true);
            if (editForm.ShowDialog(this) != DialogResult.OK)
                return;

            var newItem = editForm.Result;
            if (_items.Any(i => string.Equals(i.Index, newItem.Index, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show(this, $"Label \"{newItem.Index}\" is already used by another row in this task.",
                    "Duplicate label", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _items.Add(newItem);
            PopulateListView();
            SaveEditedTask();

            Log($"Row ADDED: {newItem.Index} | {newItem.Name} | weight={newItem.Weight} qty={newItem.Quantity}");
            _log.Log(_user.Id, _user.Name, "RowAdded", $"{newItem.Index} | {newItem.Name} | weight={newItem.Weight} qty={newItem.Quantity}");

            // If nothing was in progress (e.g. task was empty/complete), start on the new row.
            if (_currentIndex < 0 || _currentIndex >= _items.Count - 1)
                await AdvanceTo(_items.Count - 1);
        }

        private async Task EditCurrentItem()
        {
            if (_currentIndex < 0 || _currentIndex >= _items.Count)
            {
                MessageBox.Show(this, "No current item to edit.", "Nothing to edit", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var item = _items[_currentIndex];
            var before = $"name={item.Name} weight={item.Weight} qty={item.Quantity} length={item.LengthMm}";

            using var editForm = new TaskItemEditForm(item, isNewItem: false);
            if (editForm.ShowDialog(this) != DialogResult.OK)
                return;

            item.Name = editForm.Result.Name;
            item.Weight = editForm.Result.Weight;
            item.Quantity = editForm.Result.Quantity;
            item.LengthMm = editForm.Result.LengthMm;

            PopulateListView();
            SaveEditedTask();

            var after = $"name={item.Name} weight={item.Weight} qty={item.Quantity} length={item.LengthMm}";
            Log($"Row {_currentIndex + 1} EDITED: {item.Index} | before: {before} | after: {after}");
            _log.Log(_user.Id, _user.Name, "RowEdited", $"{item.Index} | before: {before} | after: {after}");

            await AdvanceTo(_currentIndex); // refresh the current-item display and re-highlight
        }

        private async Task DeleteCurrentItem()
        {
            if (_currentIndex < 0 || _currentIndex >= _items.Count)
            {
                MessageBox.Show(this, "No current item to delete.", "Nothing to delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var item = _items[_currentIndex];
            var confirm = MessageBox.Show(this, $"Delete \"{item.Name}\" [{item.Index}]? This cannot be undone.",
                "Confirm delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes)
                return;

            _items.RemoveAt(_currentIndex);
            PopulateListView();
            SaveEditedTask();

            Log($"Row DELETED: {item.Index} | {item.Name} | weight={item.Weight} qty={item.Quantity}");
            _log.Log(_user.Id, _user.Name, "RowDeleted", $"{item.Index} | {item.Name} | weight={item.Weight} qty={item.Quantity}");

            // Stay on the same position (now the next row), unless we deleted the last one.
            var nextIndex = Math.Min(_currentIndex, _items.Count - 1);
            _currentIndex = -1; // force AdvanceTo to treat this as a fresh move
            await AdvanceTo(Math.Max(nextIndex, 0));
        }

        /// <summary>
        /// Saves the current in-memory item list to a separate "_edited"
        /// file next to the originally loaded task, so the admin-provided
        /// source file is never overwritten - only the current working
        /// state is persisted, while OperationsLog keeps the full change
        /// history for audit purposes.
        /// </summary>
        private void SaveEditedTask()
        {
            if (string.IsNullOrEmpty(_currentTaskFilePath))
                return;

            try
            {
                var dir = Path.GetDirectoryName(_currentTaskFilePath) ?? AppDomain.CurrentDomain.BaseDirectory;
                var baseName = Path.GetFileNameWithoutExtension(_currentTaskFilePath);
                // Once already saved as "_edited", keep saving to the same
                // file rather than stacking "_edited_edited_edited...".
                if (baseName.EndsWith("_edited", StringComparison.OrdinalIgnoreCase))
                {
                    var editedPath = Path.Combine(dir, baseName + ".csv");
                    TaskCsvLoader.Save(_items, editedPath);
                }
                else
                {
                    var editedPath = Path.Combine(dir, baseName + "_edited.csv");
                    TaskCsvLoader.Save(_items, editedPath);
                    _currentTaskFilePath = editedPath; // subsequent saves go to this file
                }
            }
            catch (Exception ex)
            {
                Log($"Failed to save edited task file: {ex.Message}");
            }
        }

        private void DoLogout()
        {
            _log.Log(_user.Id, _user.Name, "Logout", "");
            StopAutoRecheck();
            DisposeHardware();
            LogoutRequested?.Invoke();
            Hide();
        }

        private void DisposeHardware()
        {
            (_relay as IDisposable)?.Dispose();
            _scale?.Dispose();
            _relay = null;
            _matrix = null;
            _scale = null;
        }

        private void Log(string message)
        {
            if (_logBox.IsHandleCreated && _logBox.InvokeRequired)
            {
                BeginInvoke((Action)(() => Log(message)));
                return;
            }
            _logBox.AppendText($"{DateTime.Now:HH:mm:ss} {message}{Environment.NewLine}");
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _healthCheckTimer.Dispose();
            DisposeHardware();
            base.OnFormClosed(e);
        }
    }
}
