using System;
using System.IO;
using System.Text;

namespace LedMatrixControl
{
    /// <summary>
    /// Appends one human-readable line per operator action to a plain text
    /// log. Always writes to a local file next to the executable first
    /// (never blocked by network issues), then makes a best-effort attempt
    /// to mirror the same line to the network log folder. A network
    /// failure never loses the local record.
    /// </summary>
    public class OperationsLog
    {
        private readonly string _localPath;
        private readonly string _networkFolder;
        private readonly object _lock = new();

        public OperationsLog(string localFolder, string networkFolder)
        {
            var fileName = $"operations_log_{DateTime.Now:yyyyMMdd}.txt";
            _localPath = Path.Combine(localFolder, fileName);
            _networkFolder = networkFolder;
        }

        public void Log(string userId, string userName, string action, string details)
        {
            var line = BuildLine(userId, userName, action, details);

            lock (_lock)
            {
                AppendLocal(line);
                TryAppendNetwork(line);
            }
        }

        private static string BuildLine(string userId, string userName, string action, string details)
        {
            var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}  |  {userName} ({userId})  |  {action}";
            if (!string.IsNullOrWhiteSpace(details))
                line += $"  |  {details}";
            return line;
        }

        private void AppendLocal(string line)
        {
            try
            {
                File.AppendAllText(_localPath, line + Environment.NewLine, Encoding.UTF8);
            }
            catch
            {
                // If even the local log can't be written, there's nowhere
                // safe left to report it - swallow rather than crash the
                // operator's workflow.
            }
        }

        private void TryAppendNetwork(string line)
        {
            try
            {
                if (!Directory.Exists(_networkFolder))
                    return;

                var fileName = Path.GetFileName(_localPath);
                var networkPath = Path.Combine(_networkFolder, fileName);
                File.AppendAllText(networkPath, line + Environment.NewLine, Encoding.UTF8);
            }
            catch
            {
                // Network unreachable or locked: local copy already has the
                // record, so this is safe to ignore.
            }
        }
    }
}
