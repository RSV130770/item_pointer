using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace LedMatrixControl
{
    public class CellLabel
    {
        public int Row { get; set; }
        public int Col { get; set; }
        public string Label { get; set; } = "";
    }

    /// <summary>
    /// Persists per-cell text labels (e.g. friendly names for each LED) to
    /// a JSON file. Labels are capped at 5 characters.
    /// </summary>
    public class LabelStore
    {
        public const int MaxLabelLength = 5;

        private readonly string _path;
        private readonly Dictionary<(int Row, int Col), string> _labels = new();

        public LabelStore(string path)
        {
            _path = path;
            Load();
        }

        public string Get(int row, int col) =>
            _labels.TryGetValue((row, col), out var label) ? label : "";

        /// <summary>
        /// Finds the (row, col) for a given label. Case-insensitive.
        /// Returns false if no cell has that label.
        /// </summary>
        public bool TryFind(string label, out int row, out int col)
        {
            label = (label ?? "").Trim();
            foreach (var kvp in _labels)
            {
                if (string.Equals(kvp.Value, label, StringComparison.OrdinalIgnoreCase))
                {
                    row = kvp.Key.Row;
                    col = kvp.Key.Col;
                    return true;
                }
            }
            row = -1;
            col = -1;
            return false;
        }

        /// <summary>
        /// Sets the label for a cell. Returns false without saving if that
        /// label is already used by a different cell (labels must be unique;
        /// empty/blank labels are always allowed and don't count as a
        /// duplicate).
        /// </summary>
        public bool Set(int row, int col, string label)
        {
            label = (label ?? "").Trim();
            if (label.Length > MaxLabelLength)
                label = label.Substring(0, MaxLabelLength);

            if (!string.IsNullOrEmpty(label) &&
                TryFind(label, out int existingRow, out int existingCol) &&
                (existingRow != row || existingCol != col))
            {
                return false;
            }

            if (string.IsNullOrEmpty(label))
                _labels.Remove((row, col));
            else
                _labels[(row, col)] = label;

            Save();
            return true;
        }

        private void Load()
        {
            if (!File.Exists(_path))
                return;

            try
            {
                var json = File.ReadAllText(_path);
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var list = JsonSerializer.Deserialize<List<CellLabel>>(json, options) ?? new List<CellLabel>();
                foreach (var entry in list)
                {
                    if (!string.IsNullOrEmpty(entry.Label))
                        _labels[(entry.Row, entry.Col)] = entry.Label;
                }
            }
            catch
            {
                // Corrupt or unreadable file: start with no labels rather than crash.
            }
        }

        private void Save()
        {
            var list = new List<CellLabel>();
            foreach (var kvp in _labels)
                list.Add(new CellLabel { Row = kvp.Key.Row, Col = kvp.Key.Col, Label = kvp.Value });

            var options = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText(_path, JsonSerializer.Serialize(list, options));
        }
    }
}
