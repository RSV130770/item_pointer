using System;
using System.Windows.Forms;
using System.Drawing;

namespace LedMatrixControl
{
    public class TaskItemEditForm : Form
    {
        private readonly TextBox _indexBox = new() { Font = new Font(FontFamily.GenericSansSerif, 16), Dock = DockStyle.Fill };
        private readonly TextBox _nameBox = new() { Font = new Font(FontFamily.GenericSansSerif, 16), Dock = DockStyle.Fill };
        private readonly TextBox _weightBox = new() { Font = new Font(FontFamily.GenericSansSerif, 16), Dock = DockStyle.Fill };
        private readonly TextBox _quantityBox = new() { Font = new Font(FontFamily.GenericSansSerif, 16), Dock = DockStyle.Fill };
        private readonly TextBox _lengthBox = new() { Font = new Font(FontFamily.GenericSansSerif, 16), Dock = DockStyle.Fill };
        private readonly Label _errorLabel = new() { Font = new Font(FontFamily.GenericSansSerif, 12), ForeColor = Color.Red, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };

        private readonly bool _indexEditable;

        public TaskItem Result { get; private set; }

        /// <summary>
        /// isNewItem = true shows an editable Index/label field (for adding
        /// a new row); false locks it read-only (editing an existing row
        /// keeps its LED label fixed).
        /// </summary>
        public TaskItemEditForm(TaskItem existing, bool isNewItem)
        {
            _indexEditable = isNewItem;
            Text = isNewItem ? "Add item" : "Edit item";
            WindowState = FormWindowState.Maximized;
            FormBorderStyle = FormBorderStyle.None;
            BackColor = Color.White;

            BuildLayout();

            if (existing != null)
            {
                _indexBox.Text = existing.Index;
                _nameBox.Text = existing.Name;
                _weightBox.Text = existing.Weight.ToString();
                _quantityBox.Text = existing.Quantity.ToString();
                _lengthBox.Text = existing.LengthMm?.ToString() ?? "";
            }
            _indexBox.ReadOnly = !_indexEditable;
            if (!_indexEditable)
                _indexBox.BackColor = SystemColors.Control;
        }

        private void BuildLayout()
        {
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 7, Padding = new Padding(30) };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            AddRow(root, 0, "Label (index):", _indexBox);
            AddRow(root, 1, "Name:", _nameBox);
            AddRow(root, 2, "Unit weight (g):", _weightBox);
            AddRow(root, 3, "Quantity:", _quantityBox);
            AddRow(root, 4, "Length (mm, optional):", _lengthBox);

            root.Controls.Add(_errorLabel, 0, 5);
            root.SetColumnSpan(_errorLabel, 2);

            var buttonRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            buttonRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            buttonRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            var saveButton = new Button { Text = "Save", Dock = DockStyle.Fill, Margin = new Padding(15), Font = new Font(FontFamily.GenericSansSerif, 18, FontStyle.Bold) };
            var cancelButton = new Button { Text = "Cancel", Dock = DockStyle.Fill, Margin = new Padding(15), Font = new Font(FontFamily.GenericSansSerif, 18) };
            saveButton.Click += (s, e) => OnSaveClicked();
            cancelButton.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            buttonRow.Controls.Add(saveButton, 0, 0);
            buttonRow.Controls.Add(cancelButton, 1, 0);
            root.Controls.Add(buttonRow, 0, 6);
            root.SetColumnSpan(buttonRow, 2);

            Controls.Add(root);
        }

        private static void AddRow(TableLayoutPanel root, int rowIndex, string labelText, Control input)
        {
            root.Controls.Add(new Label { Text = labelText, Dock = DockStyle.Fill, Font = new Font(FontFamily.GenericSansSerif, 14), TextAlign = ContentAlignment.MiddleLeft }, 0, rowIndex);
            root.Controls.Add(input, 1, rowIndex);
        }

        private void OnSaveClicked()
        {
            var index = _indexBox.Text.Trim();
            var name = _nameBox.Text.Trim();

            if (string.IsNullOrEmpty(index)) { ShowError("Label is required."); return; }
            if (string.IsNullOrEmpty(name)) { ShowError("Name is required."); return; }
            if (!double.TryParse(_weightBox.Text.Trim(), out var weight) || weight < 0) { ShowError("Weight must be a non-negative number."); return; }
            if (!int.TryParse(_quantityBox.Text.Trim(), out var quantity) || quantity < 0) { ShowError("Quantity must be a non-negative whole number."); return; }

            double? length = null;
            var lengthText = _lengthBox.Text.Trim();
            if (!string.IsNullOrEmpty(lengthText))
            {
                if (!double.TryParse(lengthText, out var lengthValue) || lengthValue < 0) { ShowError("Length must be a non-negative number, or left blank."); return; }
                length = lengthValue;
            }

            Result = new TaskItem { Index = index, Name = name, Weight = weight, Quantity = quantity, LengthMm = length };
            DialogResult = DialogResult.OK;
            Close();
        }

        private void ShowError(string message)
        {
            _errorLabel.Text = message;
        }
    }
}
