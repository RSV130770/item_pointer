using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace LedMatrixControl
{
    public static class TaskCsvLoader
    {
        /// <summary>
        /// Loads a task list from a CSV file. Expects a header row containing
        /// (case-insensitively) columns: index, weight, name, quantity, and
        /// optionally precision. Column order does not matter.
        /// </summary>
        public static List<TaskItem> Load(string path)
        {
            var lines = File.ReadAllLines(path);
            if (lines.Length == 0)
                throw new InvalidDataException("CSV file is empty.");

            var headers = SplitCsvLine(lines[0]);
            int indexCol = FindColumn(headers, "index");
            int weightCol = FindColumn(headers, "weight");
            int nameCol = FindColumn(headers, "name");
            int qtyCol = FindColumn(headers, "quantity");
            int precisionCol = FindColumn(headers, "precision"); // optional, -1 if absent
            int lengthCol = FindColumn(headers, "length_mm");    // optional, -1 if absent

            if (indexCol < 0 || weightCol < 0 || nameCol < 0 || qtyCol < 0)
                throw new InvalidDataException("CSV must contain 'index', 'weight', 'name', and 'quantity' columns.");

            var items = new List<TaskItem>();
            for (int i = 1; i < lines.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(lines[i]))
                    continue;

                var fields = SplitCsvLine(lines[i]);
                var item = new TaskItem
                {
                    Index = SafeGet(fields, indexCol).Trim(),
                    Weight = ParseFlexibleDouble(SafeGet(fields, weightCol)),
                    Name = SafeGet(fields, nameCol).Trim(),
                    Quantity = (int)ParseFlexibleDouble(SafeGet(fields, qtyCol))
                };

                if (precisionCol >= 0)
                {
                    var raw = SafeGet(fields, precisionCol);
                    if (!string.IsNullOrWhiteSpace(raw))
                        item.Precision = ParseFlexibleDouble(raw);
                }

                if (lengthCol >= 0)
                {
                    var raw = SafeGet(fields, lengthCol);
                    if (!string.IsNullOrWhiteSpace(raw))
                        item.LengthMm = ParseFlexibleDouble(raw);
                }

                items.Add(item);
            }

            return items;
        }

        public static void Save(List<TaskItem> items, string path)
        {
            var lines = new List<string> { "index,name,weight,quantity,precision,length_mm" };
            foreach (var item in items)
            {
                lines.Add(string.Join(",",
                    CsvField(item.Index),
                    CsvField(item.Name),
                    item.Weight.ToString(CultureInfo.InvariantCulture),
                    item.Quantity.ToString(CultureInfo.InvariantCulture),
                    item.Precision?.ToString(CultureInfo.InvariantCulture) ?? "",
                    item.LengthMm?.ToString(CultureInfo.InvariantCulture) ?? ""));
            }
            File.WriteAllLines(path, lines);
        }

        private static string CsvField(string value)
        {
            value ??= "";
            if (value.Contains(',') || value.Contains('"'))
                return "\"" + value.Replace("\"", "\"\"") + "\"";
            return value;
        }

        /// <summary>Parses a double accepting either '.' or ',' as the decimal separator.</summary>
        public static double ParseFlexibleDouble(string raw)
        {
            raw = (raw ?? "").Trim();
            if (double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var value))
                return value;

            // Fall back: treat comma as decimal separator.
            var normalized = raw.Replace(".", "").Replace(",", ".");
            if (double.TryParse(normalized, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                return value;

            throw new FormatException($"Could not parse number: \"{raw}\"");
        }

        private static string SafeGet(List<string> fields, int index) =>
            index >= 0 && index < fields.Count ? fields[index] : "";

        private static int FindColumn(List<string> headers, string name) =>
            headers.FindIndex(h => string.Equals(h.Trim(), name, StringComparison.OrdinalIgnoreCase));

        private static List<string> SplitCsvLine(string line)
        {
            // Minimal CSV split: handles simple comma or semicolon separated
            // values with optional double-quote wrapping. Not a full RFC4180
            // parser (no embedded commas-in-quotes edge cases beyond basics).
            char separator = line.Contains(';') && !line.Contains(',') ? ';' : ',';
            return line.Split(separator).Select(f => f.Trim().Trim('"')).ToList();
        }
    }
}
