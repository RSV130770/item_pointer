using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace LedMatrixControl
{
    public class RelayControlForm : Form
    {
        private readonly TextBox _portNameBox = new() { Text = "COM3", Width = 80 };
        private readonly Button _connectButton = new() { Text = "Connect", Width = 90 };
        private readonly Button _allOffButton = new() { Text = "All off", Width = 90 };
        private readonly TextBox _searchBox = new() { Width = 60, MaxLength = LabelStore.MaxLabelLength };
        private readonly Button _searchButton = new() { Text = "Find label", Width = 90 };
        private readonly Button _openTaskButton = new() { Text = "Open task window", Width = 140 };
        private readonly Button _openConfigButton = new() { Text = "Config editor", Width = 120 };
        private readonly TextBox _logBox = new()
        {
            Multiline = true,
            ScrollBars = ScrollBars.Vertical,
            ReadOnly = true,
            Dock = DockStyle.Bottom,
            Height = 140
        };

        private readonly TableLayoutPanel _grid = new() { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(0, 50, 0, 0) };

        private LedMatrixConfig _config;
        private IRelayCommutator _hardware = new MockRelayCommutator();
        private LedMatrix _matrix;
        private Button[,] _ledButtons;
        private Button[] _rowHeaderButtons;
        private Button[] _colHeaderButtons;
        private readonly LabelStore _labels = new("index.json");

        private bool _usesExternalHardware;

        public RelayControlForm()
        {
            Text = "LED matrix manual control";
            Width = 1000;
            Height = 700;

            _config = LoadConfigOrDefault();
            _portNameBox.Text = _config.SerialPort.PortName;
            _matrix = new LedMatrix(_hardware, _config);

            BuildTopBar();
            BuildGrid(_config.Rows, _config.TotalColumns > 0 ? _config.TotalColumns : 32);

            Controls.Add(_grid);
            Controls.Add(_logBox);
        }

        /// <summary>
        /// Reuses an already-open relay connection (e.g. the one TaskForm
        /// is holding) instead of opening the COM port a second time, which
        /// would fail since only one connection can hold a serial port at
        /// once. The port/connect controls are hidden since there's nothing
        /// for them to do here.
        /// </summary>
        public RelayControlForm(LedMatrixConfig config, LedMatrix existingMatrix)
        {
            Text = "LED matrix manual control (shared connection)";
            Width = 1000;
            Height = 700;

            _config = config;
            _matrix = existingMatrix;
            _usesExternalHardware = true;

            BuildTopBar();
            BuildGrid(_config.Rows, _config.TotalColumns > 0 ? _config.TotalColumns : 32);

            Controls.Add(_grid);
            Controls.Add(_logBox);

            Log("Using the relay connection already open elsewhere in the app.");
        }

        private LedMatrixConfig LoadConfigOrDefault()
        {
            const string path = "config.json";
            try
            {
                if (File.Exists(path))
                {
                    Log($"Loaded config from {Path.GetFullPath(path)}");
                    return LedMatrixConfig.LoadFromFile(path);
                }
            }
            catch (Exception ex)
            {
                Log($"Failed to load {path}: {ex.Message}. Using built-in default.");
            }

            Log($"{path} not found next to the executable. Using built-in default (16x32, addr 2/3).");
            return new LedMatrixConfig
            {
                RowCommutator = new RowCommutatorConfig { Address = 1 },
                ColumnCommutators = new List<ColumnCommutatorConfig>
                {
                    new() { Address = 2, StartColumn = 0 },
                    new() { Address = 3, StartColumn = 16 }
                },
                Rows = 16,
                ColumnsPerCommutator = 16,
                AllChannelsValue = 255
            };
        }

        private void BuildTopBar()
        {
            var topBar = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 40,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(8)
            };
            var portLabel = new Label { Text = "Port:", AutoSize = true, Margin = new Padding(0, 8, 4, 0) };
            topBar.Controls.Add(portLabel);
            topBar.Controls.Add(_portNameBox);
            topBar.Controls.Add(_connectButton);
            topBar.Controls.Add(_allOffButton);
            topBar.Controls.Add(new Label { Text = "Label:", AutoSize = true, Margin = new Padding(20, 8, 4, 0) });
            topBar.Controls.Add(_searchBox);
            topBar.Controls.Add(_searchButton);
            topBar.Controls.Add(_openTaskButton);
            topBar.Controls.Add(_openConfigButton);

            if (_usesExternalHardware)
            {
                portLabel.Visible = false;
                _portNameBox.Visible = false;
                _connectButton.Visible = false;
                _openTaskButton.Visible = false; // avoid opening a second TaskForm that would fight over the same port
            }

            _searchButton.Click += async (s, e) => await SetLedByLabel(_searchBox.Text);
            _openTaskButton.Click += (s, e) =>
            {
                // Technician bypass: opens the task window directly without
                // going through the PIN login screen, for testing.
                var technicianUser = new AppUser { Id = "tech", Name = "Technician (bypass)" };
                new TaskForm(_config, technicianUser).Show();
            };
            _openConfigButton.Click += (s, e) => new ConfigEditorForm("config.json").Show();

            _connectButton.Click += OnConnectClicked;
            _allOffButton.Click += OnAllOffClicked;

            Controls.Add(topBar);
        }

        private void BuildGrid(int rows, int cols)
        {
            _grid.ColumnCount = cols + 1;
            _grid.RowCount = rows + 1;
            for (int c = 0; c <= cols; c++)
                _grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60));
            for (int r = 0; r <= rows; r++)
                _grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));

            _ledButtons = new Button[rows, cols];
            _rowHeaderButtons = new Button[rows];
            _colHeaderButtons = new Button[cols];

            _grid.Controls.Add(new Label { Text = "", Dock = DockStyle.Fill }, 0, 0);

            for (int col = 0; col < cols; col++)
            {
                int capturedCol = col;
                var colHeader = new Button { Text = col.ToString(), Dock = DockStyle.Fill, Margin = new Padding(1), Font = new Font(Font.FontFamily, 7) };
                colHeader.Click += async (s, e) => await RunHardwareAction(() => _matrix.SetFullColumn(capturedCol), $"full column {capturedCol}", HighlightColumn(capturedCol));
                _colHeaderButtons[col] = colHeader;
                _grid.Controls.Add(colHeader, col + 1, 0);
            }

            for (int row = 0; row < rows; row++)
            {
                int capturedRow = row;
                var rowHeader = new Button { Text = row.ToString(), Dock = DockStyle.Fill, Margin = new Padding(1), Font = new Font(Font.FontFamily, 7) };
                rowHeader.Click += async (s, e) => await RunHardwareAction(() => _matrix.SetFullRow(capturedRow), $"full row {capturedRow}", HighlightRow(capturedRow));
                _rowHeaderButtons[row] = rowHeader;
                _grid.Controls.Add(rowHeader, 0, row + 1);

                for (int col = 0; col < cols; col++)
                {
                    int capturedCol = col;
                    var ledButton = new Button
                    {
                        Dock = DockStyle.Fill,
                        Margin = new Padding(1),
                        BackColor = SystemColors.Control,
                        Text = _labels.Get(capturedRow, capturedCol),
                        Font = new Font(Font.FontFamily, 8)
                    };
                    ledButton.Click += async (s, e) => await RunHardwareAction(() => _matrix.SetLed(capturedRow, capturedCol), $"LED ({capturedRow},{capturedCol})", HighlightSingle(capturedRow, capturedCol));
                    ledButton.MouseUp += (s, e) =>
                    {
                        if (e.Button == MouseButtons.Right)
                            EditLabel(capturedRow, capturedCol, ledButton);
                    };
                    _ledButtons[row, col] = ledButton;
                    _grid.Controls.Add(ledButton, col + 1, row + 1);
                }
            }
        }

        /// <summary>
        /// Finds the cell with the given label (case-insensitive) and turns
        /// on that LED, same as clicking it directly. Returns false if no
        /// cell currently has that label.
        /// </summary>
        public async Task<bool> SetLedByLabel(string label)
        {
            if (!_labels.TryFind(label, out int row, out int col))
            {
                Log($"Label \"{label}\" not found");
                return false;
            }

            await RunHardwareAction(() => _matrix.SetLed(row, col), $"LED by label \"{label}\" -> ({row},{col})", HighlightSingle(row, col));
            return true;
        }

        private void EditLabel(int row, int col, Button button)
        {
            var current = _labels.Get(row, col);
            using var prompt = new LabelPromptForm($"Label for ({row},{col})", current);
            if (prompt.ShowDialog(this) != DialogResult.OK)
                return;

            if (_labels.Set(row, col, prompt.ResultLabel))
            {
                button.Text = _labels.Get(row, col);
                Log($"Saved label for ({row},{col}): \"{button.Text}\" -> index.json");
            }
            else
            {
                MessageBox.Show(this, $"Label \"{prompt.ResultLabel}\" is already used by another cell. Labels must be unique.",
                    "Duplicate label", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Log($"Rejected duplicate label \"{prompt.ResultLabel}\" for ({row},{col})");
            }
        }

        private Action HighlightSingle(int row, int col)
        {
            return () =>
            {
                ClearHighlights();
                _ledButtons[row, col].BackColor = Color.LimeGreen;
            };
        }

        private Action HighlightRow(int row)
        {
            return () =>
            {
                ClearHighlights();
                for (int c = 0; c < _ledButtons.GetLength(1); c++)
                    _ledButtons[row, c].BackColor = Color.LimeGreen;
            };
        }

        private Action HighlightColumn(int col)
        {
            return () =>
            {
                ClearHighlights();
                for (int r = 0; r < _ledButtons.GetLength(0); r++)
                    _ledButtons[r, col].BackColor = Color.LimeGreen;
            };
        }

        private void ClearHighlights()
        {
            foreach (var btn in _ledButtons)
                btn.BackColor = SystemColors.Control;
        }

        private async void OnAllOffClicked(object sender, EventArgs e)
        {
            await RunHardwareAction(() => _matrix.AllOff(), "all off", ClearHighlights);
        }

        private void OnConnectClicked(object sender, EventArgs e)
        {
            try
            {
                if (_hardware is IDisposable disposable)
                    disposable.Dispose();

                _config.SerialPort.PortName = _portNameBox.Text;
                var modbus = new ModbusRelayCommutator(_config.SerialPort);
                modbus.Trace += line => { if (IsHandleCreated) BeginInvoke((Action)(() => Log(line))); };
                _hardware = modbus;

                _matrix = new LedMatrix(_hardware, _config);
                Log($"Connected ({_portNameBox.Text})");
            }
            catch (Exception ex)
            {
                Log($"Connect failed: {ex.Message}");
            }
        }

        private async Task RunHardwareAction(Action action, string description, Action onSuccessUiUpdate)
        {
            SetInputsEnabled(false);
            try
            {
                await Task.Run(action);
                onSuccessUiUpdate();
                Log($"OK: {description}");
            }
            catch (Exception ex)
            {
                Log($"FAILED: {description} - {ex.Message}");
            }
            finally
            {
                SetInputsEnabled(true);
            }
        }

        private void SetInputsEnabled(bool enabled)
        {
            _grid.Enabled = enabled;
            _allOffButton.Enabled = enabled;
            _connectButton.Enabled = enabled;
        }

        private void Log(string message)
        {
            _logBox.AppendText($"{DateTime.Now:HH:mm:ss} {message}{Environment.NewLine}");
        }
    }
}
